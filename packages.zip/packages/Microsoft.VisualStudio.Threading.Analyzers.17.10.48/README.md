# Microsoft.VisualStudio.Threading.Analyzers

Static code analyzers to detect common mistakes or potential issues regarding threading and async coding.

[Diagnostic analyzer rules](https://github.com/microsoft/vs-threading/blob/main/doc/analyzers/index.md).
